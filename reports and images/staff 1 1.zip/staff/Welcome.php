<!DOCTYPE html>
<html lang="en">
<head>
    <title>Welcome</title>
</head>
<body>
    <center>
        <h2>Welcome to the Staff Section</h2>
        <a href="./view/registration.php">Go to Registration Page</a><br>
        <a href="./view/login.php">Go to Login Page</a>
    </center>
</body>
</html>
